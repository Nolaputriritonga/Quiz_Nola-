<h2>Dashboard</h2>

<div class="info">Selamat datang</div>
<?php

namespace App\Models;

use App\Core\Model;

class Post extends Model
{

     public function show()
     {
          $query = "SELECT p.*, c.* FROM tb_posts p
          INNER JOIN tb_categories c
          ON p.post_id_cat=c.cat_id ORDER BY post_id";

          $stmt = $this->db->prepare($query);
          $stmt->execute();

          return $this->selects($stmt);
     }

     public function optCat()
     {
          $query = "SELECT * FROM tb_categories";
          $stmt = $this->db->prepare($query);
          $stmt->execute();

          return $this->selects($stmt);
     }

     public function save()
     {
          $gol_id_cat = $_POST['gol_id_cat'];
          $gol_title = $_POST['gol_title'];
          $gol_text = $_POST['gol_text'];

          $sql = "INSERT INTO tb_posts
            SET gol_id_cat=:gol_id_cat, gol_title=:gol_title, gol_text=:gol_text";
          $stmt = $this->db->prepare($sql);

          $stmt->bindParam(":gol_id_cat", $post_id_cat);
          $stmt->bindParam(":gol_title", $post_title);
          $stmt->bindParam(":gol_text", $post_text);

          $stmt->execute();
     }

     public function edit($id)
     {
          $query = "SELECT * FROM tb_gol WHERE gol_id=:gol_id";
          $stmt = $this->db->prepare($query);

          $stmt->bindParam(":gol_id", $id);
          $stmt->execute();

          return $this->select($stmt);
     }

     public function update()
     {
          $gol_id_cat = $_POST['gol_id_cat'];
          $gol_title = $_POST['gol_title'];
          $gol_text = $_POST['gol_text'];
          $id = $_gol['id'];

          $sql = "UPDATE tb_gol
                  SET gol_id_cat=:gol_id_cat, gol_title=:gol_title, gol_text=:gol_text
                  WHERE gol_id=:gol_id";

          $stmt = $this->db->prepare($sql);

          $stmt->bindParam(":gol_id_cat", $gol_id_cat);
          $stmt->bindParam(":gol_title", $gol_title);
          $stmt->bindParam(":gol_text", $gol_text);
          $stmt->bindParam(":gol_id", $id);

          $stmt->execute();
     }

     public function delete($id)
     {
          $sql = "DELETE FROM tb_pgol WHERE post_id=:post_id";
          $stmt = $this->db->prepare($sql);

          $stmt->bindParam(":post_id", $id);
          $stmt->execute();
     }
}
